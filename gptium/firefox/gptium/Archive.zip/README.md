<div align="center">

# 🤖 | GPTium

</div>

<div align="center">

---

[Српски (🇷🇸)](README.md) | [English (🇬🇧)](README-en.md)

---

</div>

</div>

<br>

<div align="center">
<p>
<a href="https://github.com/crnobog69/gptium/stargazers"><img src="https://img.shields.io/github/stars/crnobog69/gptium?style=for-the-badge&logo=starship&color=C9CBFF&logoColor=C9CBFF&labelColor=302D41" alt="stars"><a>&nbsp;&nbsp;
<a href="https://github.com/crnobog69/gptium/"><img src="https://img.shields.io/github/repo-size/crnobog69/gptium?style=for-the-badge&logo=linux&logoColor=f9e2af&label=Size&labelColor=302D41&color=f9e2af" alt="REPO SIZE"></a>&nbsp;&nbsp;
<a href="https://github.com/crnobog69/gptium/commits/main/"><img src="https://img.shields.io/github/last-commit/crnobog69/gptium?style=for-the-badge&logo=github&logoColor=eba0ac&label=Last%20Commit&labelColor=302D41&color=eba0ac" alt="Last Commit"></a>&nbsp;&nbsp;
<a href="https://github.com/crnobog69/gptium/LICENSE"><img src="https://img.shields.io/github/license/crnobog69/gptium?style=for-the-badge&logo=&color=CBA6F7&logoColor=CBA6F7&labelColor=302D41" alt="LICENSE"></a>&nbsp;&nbsp;
</p>
</div>

🔗 **Gptium** је додатак који вам омогућава да директно пошаљете изабрани текст на ChatGPT.

## 📦 | Инсталација

### 🦊 | Firefox

1. Клонирајте репозиторијум или преузмите датотеке
2. Распакујте `.zip` датотеку
3. За Firefox прегледач, потребна вам је фасцикла која се налази у [`firefox/cobaltium`](firefox/cobaltium)
4. Идите на `about:debugging`
5. Кликните на `This Firefox`
6. Кликните на `Load Temporary Add-on` и изаберите `manifest.json`
7. (Ако не видите `Load Temporary Add-on`, покушајте да преузмете `Firefox Developer Edition`)

## 🚀 | Употреба

- Изаберите текст на било којој веб страници
- Кликните на иконицу додатка да отворите ChatGPT са изабраним текстом

## 📜 | Лиценца

Овај пројекат је лиценциран под WTFPL лиценцом.
