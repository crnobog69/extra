// ==UserScript==
// @name        Better HiAnime
// @namespace   http://tampermonkey.net/
// @version     2
// @author      Ghoste
// @description Improves UX on HiAnime: Removes blur, Adds rounded corners, Speeds up the website & more.
// @icon        https://hianime.to/images/icons-192.png
// @license     MIT
// @include     *://*hianime*/*
// @grant       GM_addStyle
// @run-at      document-start
// @downloadURL https://update.greasyfork.org/scripts/506340/Better%20HiAnime.user.js
// @updateURL https://update.greasyfork.org/scripts/506340/Better%20HiAnime.meta.js
// ==/UserScript==

GM_addStyle ( `
    /* Removes the topbar blur. */
    #header.fixed {
    background-color: rgb(32 31 49) !important;
    backdrop-filter: none !important;
    }
    /* Adds rounded corners to images. */
    .film-poster {
    border-radius: 8px !important;
    }
    /* Removes the image blur effect on hover. */
    .flw-item .film-poster .film-poster-ahref:after {
    backdrop-filter:none !important;
    }
    /* Removes the background blur for the hover pop-up. */
    .qtip-default {
    backdrop-filter:none !important;
    background: rgb(81 80 100) !important;
    }
    /* Changes the transition times for hover effects. */
    .film-poster-ahref i, .film-poster-ahref:after, .film-poster-ahref:before, .film-poster-img, .preform.preform-dark .form-control, .trending-list {
    transition: all .2s ease 0s !important;
    -webkit-transition: all .2s ease 0s !important;
    }
    #header.header-home, #sidebar_menu, .block-rating .button-rate, .film-poster-ahref:after, .flw-item, .live-thumbnail-img, .lv-list .item, .profile-avatar, .rep-in .btn i, .toggle-onoff, .toggle-onoff>span, div.detail .is-info>div {
    transition: all .2s ease 0s;
    -webkit-transition: none !important;
    }
    /* Removes the description ad */
    .film-text.m-hide {
    display:none !important;
    }
    /* Removes the sharing section */
    .share-buttons {
    display:none !important;
    }
    /* Fixes the empty area left after removing the sharing section */
    .ani_detail-stage {
    margin-bottom: 0px !important;
    }
    /* Removes the comment shortcut. */
    .dt-comment {
    display:none !important;
    }
    /* Removes the Ad Banner for mobile devices. */
    .intro-app {
    display:none !important;
    }
    /* Removes the menu blur */
    #sidebar_menu_bg {
    backdrop-filter: none !important;
    }
    /* Corrects the menu color */
    #sidebar_menu {
    background: rgb(48 47 69) !important;
    }
    /* Corrects the user menu color */
    #user_menu {
    background-color: rgb(32 31 49) !important;
    backdrop-filter: none !important;
    }
` );