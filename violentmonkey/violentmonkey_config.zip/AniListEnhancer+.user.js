// ==UserScript==
// @name         AniListEnhancer+
// @namespace    http://tampermonkey.net/
// @version      0.1.4
// @description  AniListEnhancer+ for enhanced AniList experience
// @author       RoyRiv3r
// @license      MIT
// @match        https://anilist.co/*
// @connect      anidb.net
// @connect      api.jikan.moe
// @connect      raw.githubusercontent.com
// @icon         https://www.google.com/s2/favicons?sz=64&domain=anilist.co
// @require      https://cdnjs.cloudflare.com/ajax/libs/arrive/2.4.1/arrive.min.js
// @grant        GM_xmlhttpRequest
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_addStyle
// @grant        GM_registerMenuCommand

// @downloadURL https://update.greasyfork.org/scripts/504859/AniListEnhancer%2B.user.js
// @updateURL https://update.greasyfork.org/scripts/504859/AniListEnhancer%2B.meta.js
// ==/UserScript==

(function () {
  "use strict";

  // --- [START] Constants and Utilities ---

  const HOSTS = [
    {
      name: "AniList",
      storeKey: "anilist",
      baseUrl: "https://anilist.co/anime",
      favicon: "https://anilist.co/img/icons/favicon-32x32.png",
      fetchScore: null,
      cssClass: "anilist",
      color: "#02a9ff",
    },
    {
      name: "AniDB",
      storeKey: "anidb",
      baseUrl: "https://anidb.net/anime",
      favicon: "https://anidb.net/favicon.ico",
      fetchScore: fetchAniDBScore,
      cssClass: "anidb",
      color: "#fcad1b",
    },
    {
      name: "MaL",
      storeKey: "mal",
      baseUrl: "https://myanimelist.net/anime",
      favicon: "https://cdn.myanimelist.net/images/favicon.ico",
      fetchScore: fetchJikanDetails,
      cssClass: "jikan",
      color: "#2E51A2",
    },
  ];

  let cachedScores = GM_getValue("cachedScores", {});

  function getCacheExpirationTime() {
    return GM_getValue("CACHE_EXPIRATION_TIME", 1 * 60 * 60 * 1000);
  }

  function registerMenuCommand() {
    GM_registerMenuCommand("Set Cache Expiration Time", () => {
      const currentValue = getCacheExpirationTime() / (60 * 60 * 1000);
      const newValue = prompt(
        "Enter cache expiration time in hours:",
        currentValue
      );
      if (newValue !== null && !isNaN(newValue)) {
        GM_setValue("CACHE_EXPIRATION_TIME", newValue * 60 * 60 * 1000);
        alert(`Cache expiration time set to ${newValue} hours.`);
      }
    });
  }

  registerMenuCommand();

  function cleanExpiredCache() {
    const now = Date.now();
    const expirationTime = getCacheExpirationTime();

    for (const anilistID in cachedScores) {
      if (now - cachedScores[anilistID].timestamp > expirationTime) {
        delete cachedScores[anilistID];
      }
    }

    GM_setValue("cachedScores", cachedScores);
  }

  cleanExpiredCache();

  const log = (...message) => console.log("[AniListEnhancer+]", ...message);
  const error = (...message) => console.error("[AniListEnhancer+]", ...message);
  // --- [END] Constants and Utilities ---

  // --- [START] AniListScores+ Logic ---
  function fetchAniDBScore(anidbID, callback) {
    GM_xmlhttpRequest({
      method: "GET",
      url: `https://anidb.net/anime/${anidbID}`,
      onload: (response) => {
        if (response.status === 200) {
          const htmlDoc = new DOMParser().parseFromString(
            response.responseText,
            "text/html"
          );
          const averageRatingElement = htmlDoc.querySelector(
            ".tmprating .value .value"
          );
          const reviewRatingElement = htmlDoc.querySelector(
            ".reviews .value .value"
          );
          const reviewCountElement = htmlDoc.querySelector(
            ".reviews .value .count"
          );

          if (
            averageRatingElement &&
            reviewRatingElement &&
            reviewCountElement
          ) {
            const averageRating = parseFloat(averageRatingElement.textContent);
            const reviewRating = parseFloat(reviewRatingElement.textContent);
            const reviewCount = reviewCountElement.textContent.replace(
              /\(|\)/g,
              ""
            );

            const result = {
              averageRating,
              reviewRating,
              reviewCount,
            };

            callback(result);
            log(`AniDB scores fetched: ${anidbID}`);
          } else {
            log(`Rating elements not found: ${anidbID}`);
            callback({
              averageRating: "N/A",
              reviewRating: "N/A",
              reviewCount: "N/A",
            });
          }
        } else {
          log(`AniDB fetch failed: ${anidbID} - Status: ${response.status}`);
          callback({
            averageRating: "N/A",
            reviewRating: "N/A",
            reviewCount: "N/A",
          });
        }
      },
      onerror: (response) => {
        log(`AniDB fetch error: ${response.status}`);
        callback({
          averageRating: "N/A",
          reviewRating: "N/A",
          reviewCount: "N/A",
        });
      },
    });
  }

  function fetchJikanDetails(malID, callback) {
    const scoreUrl = `https://api.jikan.moe/v4/anime/${malID}`;
    const reviewsUrl = `https://api.jikan.moe/v4/anime/${malID}/reviews?preliminary=true&spoiler=true`;

    // Fetch the score
    fetch(scoreUrl)
      .then((response) => response.json())
      .then((scoreData) => {
        const score = scoreData.data.score;

        // Fetch the reviews
        fetch(reviewsUrl)
          .then((response) => response.json())
          .then((reviewData) => {
            let totalScore = 0;
            let reviewCount = 0;
            reviewData.data.forEach((review) => {
              if (review.score !== null) {
                totalScore += review.score;
                reviewCount++;
              }
            });

            const averageReviewScore =
              reviewCount > 0 ? (totalScore / reviewCount).toFixed(2) : "N/A";

            const result = {
              averageScore: score,
              averageReviewScore: averageReviewScore,
              reviewCount: reviewCount,
            };

            callback(result);
          })
          .catch((error) => {
            console.error(
              `Failed to fetch MAL reviews for malID: ${malID}. Error: ${error}`
            );
            callback({
              averageScore: "N/A",
              averageReviewScore: "N/A",
              reviewCount: "N/A",
            });
          });
      })
      .catch((error) => {
        console.error(
          `Failed to fetch MAL score for malID: ${malID}. Error: ${error}`
        );
        callback({
          averageScore: "N/A",
          averageReviewScore: "N/A",
          reviewCount: "N/A",
        });
      });
  }

  const fetchAndCacheScore = (host, hostID, anilistID, callback) => {
    const now = Date.now();
    const expirationTime = getCacheExpirationTime();

    if (
      !cachedScores[anilistID] ||
      !cachedScores[anilistID][host.storeKey] ||
      now - cachedScores[anilistID].timestamp > expirationTime
    ) {
      log(`Fetching new data for ${host.name} (ID: ${hostID})`);
      host.fetchScore(hostID, (result) => {
        if (result) {
          if (!cachedScores[anilistID]) {
            cachedScores[anilistID] = { timestamp: now };
          }
          cachedScores[anilistID][host.storeKey] = result;
          cachedScores[anilistID].timestamp = now;
          GM_setValue("cachedScores", cachedScores);
          callback(result);
        } else {
          log(`Failed to fetch data for ${host.name} (ID: ${hostID})`);
          callback(null);
        }
      });
    } else {
      log(`Using cached data for ${host.name} (ID: ${hostID})`);
      callback(cachedScores[anilistID][host.storeKey]);
    }
  };

  const createScoreHTML = (
    host,
    hostID,
    average,
    reviewRating,
    reviewCount
  ) => {
    const displayAverage =
      host.name !== "AniList" && (isNaN(average) || average === null)
        ? "N/A"
        : average;
    const displayReviewRating =
      isNaN(reviewRating) || reviewRating === null ? "N/A" : reviewRating;
    const displayReviewCount =
      isNaN(reviewCount) || reviewCount === null ? "N/A" : reviewCount;

    return `
      <a data-v-a6e466b2="" data-v-7cc43fc4=""
         href="${host.baseUrl}/${hostID}"
         target="_blank"
         class="ranking rated host-rating ${host.cssClass}"
         aria-label="${
           host.name
         } rating: ${displayAverage} average, ${displayReviewRating} review">
        <img data-v-a6e466b2="" class="host-favicon" src="${
          host.favicon
        }" alt="${host.name} Favicon" />
        <span data-v-a6e466b2="" class="host-name">${host.name}</span>
        <div class="rating-values">
          ${
            host.name === "AniDB" || host.name === "MaL"
              ? `
                <span class="average-rating">Avg: ${displayAverage}</span>
                <span class="review-rating">Rev: ${displayReviewRating} (×${displayReviewCount})</span>
              `
              : `
                <span class="average-rating">${displayAverage}</span>
              `
          }
        </div>
      </a>
    `;
  };

  const addScoresToSidebar = (sidebar, anilistToHostMap) => {
    const existingRatings = sidebar.querySelector(".host-ratings");
    if (existingRatings) existingRatings.remove();

    const anilistID = extractAnimeID(window.location.pathname);
    if (!anilistID || !anilistToHostMap[anilistID]) {
      return log(`Host IDs not found: ${anilistID}`);
    }

    const hostData = anilistToHostMap[anilistID];
    const anilistScoreElement = sidebar.querySelector(
      ".el-tooltip.data-set > .value"
    );
    if (!anilistScoreElement) {
      return log("AniList score element not found");
    }

    const anilistAverage = anilistScoreElement.textContent.trim();
    const tagsElement = sidebar.querySelector(".tags");
    if (!tagsElement) return;

    const ratingsContainer = document.createElement("div");
    ratingsContainer.classList.add("host-ratings");

    const loadingContainer = document.createElement("div");
    loadingContainer.classList.add("loading-container");
    loadingContainer.innerHTML = `
      <div class="loading-spinner"></div>
      <div class="loading-text">Loading scores...</div>
    `;
    ratingsContainer.appendChild(loadingContainer);

    sidebar.prepend(ratingsContainer);

    let loadedHosts = 0;
    const totalHosts = HOSTS.length;
    let scoresHTML = "";
    let hasError = false;

    HOSTS.forEach((host) => {
      const hostID = hostData[`${host.storeKey.toLowerCase()}_id`];

      let timeoutId = setTimeout(() => {
        hasError = true;
        loadingContainer.innerHTML = `<div class="loading-error" style="color: red;">Error loading ${host.name} score</div>`;
      }, 5000);

      if (host.name === "AniList") {
        scoresHTML += createScoreHTML(host, anilistID, anilistAverage);
        loadedHosts++;
        clearTimeout(timeoutId);
        checkAllHostsLoaded();
      } else {
        fetchAndCacheScore(host, hostID, anilistID, (result) => {
          if (host.name === "AniDB") {
            scoresHTML += createScoreHTML(
              host,
              hostID,
              result.averageRating,
              result.reviewRating,
              result.reviewCount
            );
          } else if (host.name === "MaL") {
            scoresHTML += createScoreHTML(
              host,
              hostID,
              result.averageScore,
              result.averageReviewScore,
              result.reviewCount
            );
          }
          loadedHosts++;
          clearTimeout(timeoutId);
          checkAllHostsLoaded();
        });
      }
    });

    function checkAllHostsLoaded() {
      if (loadedHosts === totalHosts && !hasError) {
        loadingContainer.remove();
        ratingsContainer.innerHTML = scoresHTML;
        ratingsContainer.style.opacity = "0";
        requestAnimationFrame(() => {
          ratingsContainer.style.transition = "opacity 0.5s ease-in-out";
          ratingsContainer.style.opacity = "1";
        });
      }
    }
  };

  const extractAnimeID = (pathname) => {
    const match = pathname.match(/\/anime\/(\d+)/);
    return match ? match[[1]] : null;
  };
  // --- [END] AniListScores+ Logic ---

  // --- [START] Anilist+ Logic ---
  function updateOverlayHeight(elementsPresent) {
    const baseHeight = 12;
    const heightPerElement = {
      score: 40,
      date: 18,
      genres: 21,
      studio: 16,
      info: 16,
    };

    let totalHeight = baseHeight;
    elementsPresent.forEach((element) => {
      totalHeight += heightPerElement[element];
    });

    return totalHeight;
  }

  // Function to display info for Anilist+
  function displayInfoOnCards() {
    const mediaCards = document.querySelectorAll(
      ".media-card:has(.hover-data)"
    );

    mediaCards.forEach((card) => {
      const hoverData = card.querySelector(".hover-data");

      if (hoverData && !card.querySelector(".poster-info")) {
        const image = card.querySelector(".image");
        const overlayDiv = document.createElement("div");
        const infoDiv = document.createElement("div");
        overlayDiv.classList.add("poster-info-overlay");
        infoDiv.classList.add("poster-info");

        const infoHeader = document.createElement("div");
        infoHeader.classList.add("info-header");

        let elementsPresent = [];

        const scoreElement = hoverData.querySelector(".score");
        if (scoreElement) {
          infoDiv.appendChild(scoreElement.cloneNode(true));
          elementsPresent.push("score");
        }

        const dateElement = hoverData.querySelector(".date");
        if (dateElement) {
          infoDiv.appendChild(dateElement.cloneNode(true));
          elementsPresent.push("date");
        }

        const genres = hoverData.querySelectorAll(".genre");
        if (genres.length > 0) {
          const genreDiv = document.createElement("div");
          genreDiv.classList.add("genres");
          genres.forEach((genre) => {
            genreDiv.appendChild(genre.cloneNode(true));
          });
          infoDiv.appendChild(genreDiv);
          elementsPresent.push("genres");
        }

        const studio = hoverData.querySelector(".studios");
        if (studio) {
          infoDiv.appendChild(studio.cloneNode(true));
          elementsPresent.push("studio");
        }

        const info = hoverData.querySelector(".info");
        if (info) {
          infoDiv.appendChild(info.cloneNode(true));
          elementsPresent.push("info");
        }

        image.parentNode.insertBefore(overlayDiv, image.nextSibling);
        image.parentNode.appendChild(infoDiv);

        const calculatedHeight = updateOverlayHeight(elementsPresent);
        console.log("Compute Height", elementsPresent, calculatedHeight);
        overlayDiv.style.height = `${calculatedHeight}px`;

        card.addEventListener("mouseenter", () => {
          infoDiv.style.display = "none";
          overlayDiv.style.display = "none";
        });

        card.addEventListener("mouseleave", () => {
          infoDiv.style.display = "flex";
          overlayDiv.style.display = "unset";
        });
      }
    });
  }
  // --- [END] Anilist+ Logic ---

  // --- [START] Initialization and Event Handling ---
  document.arrive(
    '.sidebar > div[class="tags"]',
    { existing: true, fireOnAttributesModification: true },
    (sidebarData) => {
      let lastLoadedID = null;
      let anilistToHostMap = {};

      function initialize() {
        const anilistID = extractAnimeID(window.location.pathname);

        if (!anilistID) {
          log("Invalid anime ID in URL");
          return;
        }

        if (lastLoadedID === anilistID) {
          return;
        }
        lastLoadedID = anilistID;

        log("Page loaded. Running AniListScores+");
        const sidebar = sidebarData.parentNode;
        const lastDownloadTime = GM_getValue("lastDownloadTime", 0);
        const currentTime = Date.now();

        if (
          Object.keys(anilistToHostMap).length === 0 ||
          currentTime - lastDownloadTime >= 12 * 60 * 60 * 1000
        ) {
          log("Updating anime_ids.json");
          downloadAnimeIDs((_anilistToHostMap) => {
            anilistToHostMap = _anilistToHostMap;
            GM_setValue("anilistToHostMap", JSON.stringify(anilistToHostMap));
            GM_setValue("lastDownloadTime", currentTime);
            addScoresToSidebar(sidebar, anilistToHostMap);
          });
        } else {
          log("Using cached anime_ids.json");
          anilistToHostMap = JSON.parse(GM_getValue("anilistToHostMap", "{}"));
          addScoresToSidebar(sidebar, anilistToHostMap);
        }

        displayInfoOnCards();
      }

      const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (
            mutation.type === "attributes" &&
            mutation.attributeName === "href"
          ) {
            log("URL change detected");
            setTimeout(initialize, 200);
          }
        }
      });

      const targetNode = document.querySelector("body");
      const config = { attributes: true, childList: true, subtree: true };
      observer.observe(targetNode, config);

      initialize();
    }
  );

  const infoObserver = new MutationObserver(displayInfoOnCards);
  infoObserver.observe(document.body, { childList: true, subtree: true });

  const downloadAnimeIDs = (callback) => {
    GM_xmlhttpRequest({
      method: "GET",
      url: "https://raw.githubusercontent.com/Kometa-Team/Anime-IDs/master/anime_ids.json",
      onload: (response) => {
        if (response.status === 200) {
          const data = JSON.parse(response.responseText);
          let _anilistToHostMap = {};
          for (const anidbID in data) {
            const entry = data[anidbID];
            _anilistToHostMap[entry.anilist_id] = {
              anidb_id: anidbID,
              mal_id: entry.mal_id,
            };
          }
          callback(_anilistToHostMap);
        } else {
          error(`anime_ids.json download failed: ${response.status}`);
        }
      },
      onerror: (response) => {
        error(`anime_ids.json download error: ${response.status}`);
      },
    });
  };

  GM_addStyle(`
      .tags:has(.host-rating) {
          margin-top: 0px;
          margin-bottom: 16px;
      }
      .host-rating {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 6px 10px; 
          background-color: #f2f2f2;
          border-radius: 4px;
          font-size: 14px;
          text-decoration: none;
          color: inherit;
      }
  
      .host-rating:hover {
          background-color: #f8f8f8; 
      }
  
      .host-link {
          display: flex;
          align-items: center;
          gap: 4px;
          flex: 0 0 auto;
      }
  
      .host-favicon {
          width: 16px;
          height: 16px;
      }
  
      .host-name {
          font-weight: 700; 
      }
  
      .rating-values {
          display: flex;
          align-items: center;
          gap: 8px;
      }
  
      .average-rating,
      .review-rating {
          color: #999;
          font-weight: 600; 
      }
  
      .anidb .average-rating,
      .anidb .review-rating {
          color: #fcad1b;
      }
  
      .jikan .average-rating,
      .jikan .review-rating {
          color: #2E51A2;
      }
  
      .anilist .average-rating {
          color: #3db4f2; 
      }
  
      .poster-info {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        padding: 4px;
        font-size: 14px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        text-align: center;
        align-items: center;
        gap: 2px;
        z-index: 3;
        color: white;
        transition: opacity 0.2s ease-in-out;
      }
  
      .poster-info-overlay {
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.70);
        z-index: 2;
      }
  
      .poster-info .genres {
        flex-wrap: wrap;
        height: 20px;
        overflow: hidden;
      }
  
      .poster-info .score {
        display: flex;
        flex-direction: column;
        align-items: center;
        font-weight: 700;
      }
  
      .poster-info .score > .icon {
        margin: 2px;
      }
  
      .poster-info .score + .date.airing {
        font-size: 11px;
      }
  
      .poster-info .genre {
        transform: scale(0.90);
        margin-right: 0px !important;
      }
  
      .poster-info .studios {
        display: inline-block;
        margin-top: 2px !important;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 168px;
      }
  
      .poster-info .info {
        display: flex;
        color: white !important;
        margin-top: 0px !important;
      }
      @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
      }
  
      @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
      }
  
      .host-ratings {
          animation: fadeIn 0.5s ease-in-out;
      }
  
      .loading-container {
          display: flex;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          margin: 20px 0; 
      }
  
      .loading-spinner {
          width: 40px;
          height: 40px;
          border: 4px solid #f3f3f3;
          border-top: 4px solid #3db4f2;
          border-radius: 50%;
          animation: spin 1s linear infinite;
      }
  
      .loading-text {
          margin-top: 10px;
          color: #3db4f2;
          font-weight: bold;
      }
  `);
  // --- [END] Initialization and Event Handling ---
})();
